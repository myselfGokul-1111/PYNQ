#include "cnn_top.h"

// -------------------------------
// 3x3 Convolution Function (template for in_ch/out_ch/img_size)
// -------------------------------
template<int IN_CH, int OUT_CH, int IMG_SIZE_>
void conv3x3(
    data_t in[IN_CH][IMG_SIZE_][IMG_SIZE_],
    data_t out[OUT_CH][IMG_SIZE_][IMG_SIZE_],
    const weight_t weight[OUT_CH][IN_CH][3][3],
    const weight_t bias[OUT_CH]
){
    LOOP_OUT: for(int oc=0; oc<OUT_CH; oc++)
    LOOP_ROW: for(int i=0;i<IMG_SIZE_;i++)
    LOOP_COL: for(int j=0;j<IMG_SIZE_;j++)
    
    {
        data_t sum = 0;
        LOOP_IN: for(int ic=0; ic<IN_CH; ic++)
        LOOP_KR: for(int kr=-1; kr<=1; kr++)
        LOOP_KC: for(int kc=-1; kc<=1; kc++)
        {
            int r=i+kr, c=j+kc;
            data_t val = (r>=0 && r<IMG_SIZE_ && c>=0 && c<IMG_SIZE_) ? in[ic][r][c] : data_t(0);
            sum += val * weight[oc][ic][kr+1][kc+1]; // LUT or DSP, limited by pipeline
        }
        out[oc][i][j] = sum + bias[oc];
    }
}

// -------------------------------
// MaxPool 2x2 (template)
// -------------------------------
template<int CH, int IN_SIZE>
void maxpool2x2(
    data_t in[CH][IN_SIZE][IN_SIZE],
    data_t out[CH][IN_SIZE/2][IN_SIZE/2]
){
    LOOP_CH: for(int c=0;c<CH;c++)
    LOOP_ROW: for(int i=0;i<IN_SIZE;i+=2)
    LOOP_COL: for(int j=0;j<IN_SIZE;j+=2)
    #pragma HLS PIPELINE II=2  // small II, safe for resources
    {
        data_t m = in[c][i][j];
        if(in[c][i][j+1]>m) m = in[c][i][j+1];
        if(in[c][i+1][j]>m) m = in[c][i+1][j];
        if(in[c][i+1][j+1]>m) m = in[c][i+1][j+1];
        out[c][i/2][j/2] = m;
    }
}

// -------------------------------
// Fully Connected Layer (template)
// -------------------------------
template<int IN_SIZE, int OUT_SIZE>
void fc_layer(
    data_t in[IN_SIZE],
    data_t out[OUT_SIZE],
    const weight_t weight[OUT_SIZE][IN_SIZE],
    const weight_t bias[OUT_SIZE]
){
    LOOP_OUT: for(int o=0;o<OUT_SIZE;o++)
   //#pragma HLS PIPELINE II=750// safe II for large FC, low DSP usage
    {
        data_t sum = 0;
        LOOP_IN: for(int i=0;i<IN_SIZE;i++)
            sum += in[i] * weight[o][i]; // LUT or DSP
        out[o] = sum + bias[o];
    }
}

// -------------------------------
// CNN TOP
// -------------------------------
void cnn_top(data_t input[3][IMG_SIZE][IMG_SIZE], data_t output[NUM_CLASSES])
{
#pragma HLS INTERFACE m_axi port=input  offset=slave bundle=INPUT
#pragma HLS INTERFACE m_axi port=output offset=slave bundle=OUTPUT
#pragma HLS INTERFACE s_axilite port=return bundle=CTRL

    // -------------------
    // Layer buffers
    // -------------------
    static data_t conv1_out[16][IMG_SIZE][IMG_SIZE];
    static data_t conv2_out[32][IMG_SIZE][IMG_SIZE];
    static data_t conv3_out[32][IMG_SIZE/2][IMG_SIZE/2];
    static data_t pool2_out[32][IMG_SIZE/2][IMG_SIZE/2];
    static data_t pool3_out[32][8][8];
    static data_t fc1_in[32*8*8];
    static data_t fc1_out[64];

    // -------------------
    // Conv1 + ReLU
    // -------------------
    conv3x3<3,16,IMG_SIZE>(input, conv1_out, conv1_weight, conv1_bias);
    RELU1: for(int c=0;c<16;c++)
        for(int i=0;i<IMG_SIZE;i++)
            for(int j=0;j<IMG_SIZE;j++)
    #pragma HLS PIPELINE II=4
            conv1_out[c][i][j] = conv1_out[c][i][j]>data_t(0)?conv1_out[c][i][j]:data_t(0);

    // -------------------
    // Conv2 + ReLU + MaxPool
    // -------------------
    conv3x3<16,32,IMG_SIZE>(conv1_out, conv2_out, conv2_weight, conv2_bias);
    RELU2: for(int c=0;c<32;c++)
        for(int i=0;i<IMG_SIZE;i++)
            for(int j=0;j<IMG_SIZE;j++)
   #pragma HLS PIPELINE II=4
            conv2_out[c][i][j] = conv2_out[c][i][j]>data_t(0)?conv2_out[c][i][j]:data_t(0);
    maxpool2x2<32,IMG_SIZE>(conv2_out, pool2_out);

    // -------------------
    // Conv3 + ReLU + MaxPool
    // -------------------
    conv3x3<32,32,IMG_SIZE/2>(pool2_out, conv3_out, conv3_weight, conv3_bias);
    RELU3: for(int c=0;c<32;c++)
        for(int i=0;i<IMG_SIZE/2;i++)
            for(int j=0;j<IMG_SIZE/2;j++)
   
            conv3_out[c][i][j] = conv3_out[c][i][j]>data_t(0)?conv3_out[c][i][j]:data_t(0);
    maxpool2x2<32,IMG_SIZE/2>(conv3_out, pool3_out);

    // -------------------
    // Flatten for FC
    // -------------------
    FC_FLATTEN: for(int c=0;c<32;c++)
        for(int i=0;i<8;i++)
            for(int j=0;j<8;j++)
                fc1_in[c*8*8 + i*8 + j] = pool3_out[c][i][j];

    // -------------------
    // FC1 + ReLU
    // -------------------
    fc_layer<32*8*8,64>(fc1_in, fc1_out, fc1_weight, fc1_bias);
    RELU_FC1: for(int i=0;i<64;i++)
  #pragma HLS PIPELINE II=100
        fc1_out[i] = fc1_out[i]>data_t(0)?fc1_out[i]:data_t(0);

    // -------------------
    // FC2 (Output)
    // -------------------
    fc_layer<64,NUM_CLASSES>(fc1_out, output, fc2_weight, fc2_bias);
}