#include "cnn_top.h"
#include <iostream>
#include <fstream>
#include <string>

#define NUM_IMAGES 5

void load_image_bin(const std::string &filename, data_t input[3][IMG_SIZE][IMG_SIZE]) {
    std::ifstream fin(filename, std::ios::binary);
    if(!fin) {
        std::cerr << "Cannot open file: " << filename << "\n";
        exit(1);
    }

    float tmp;
    for(int c=0;c<3;c++)
        for(int i=0;i<IMG_SIZE;i++)
            for(int j=0;j<IMG_SIZE;j++) {
                fin.read(reinterpret_cast<char*>(&tmp), sizeof(float));
                input[c][i][j] = data_t(tmp);
            }
    fin.close();
}

int main() {
    data_t input[3][IMG_SIZE][IMG_SIZE];
    data_t output[NUM_CLASSES];

    for(int img_idx=0; img_idx<NUM_IMAGES; img_idx++){
        std::string fname = "C:/Users/nvgok/OneDrive/Apps/AISOC/trybest/hls_weights/bin_images/image_" + std::to_string(img_idx) + ".bin";
        load_image_bin(fname, input);

        cnn_top(input, output);

        std::cout << "Image " << img_idx << " CNN output:\n";
        for(int i=0;i<NUM_CLASSES;i++)
            std::cout << "Class " << i << ": " << (float)output[i] << "\n";

        // Optional: predicted class
        int pred_class = 0;
        data_t max_val = output[0];  // instead of float max_val
        for(int i=1;i<NUM_CLASSES;i++)
            if(output[i] > max_val) { max_val = output[i]; pred_class = i; }
        std::cout << "Predicted class: " << pred_class << "\n\n";
    }

    return 0;
}