#include "conv2d_hls.h"

void conv2d_hls(
    data_t input[MAX_C][MAX_H][MAX_W],
    data_t weights[MAX_K][MAX_C][3][3],
    data_t bias[MAX_K],
    data_t output[MAX_K][MAX_H][MAX_W],
    int H, int W, int Cin, int Cout
) {
#pragma HLS INTERFACE m_axi port=input  offset=slave bundle=gmem
#pragma HLS INTERFACE m_axi port=weights offset=slave bundle=gmem
#pragma HLS INTERFACE m_axi port=bias    offset=slave bundle=gmem
#pragma HLS INTERFACE m_axi port=output  offset=slave bundle=gmem

#pragma HLS INTERFACE s_axilite port=H
#pragma HLS INTERFACE s_axilite port=W
#pragma HLS INTERFACE s_axilite port=Cin
#pragma HLS INTERFACE s_axilite port=Cout
#pragma HLS INTERFACE s_axilite port=return

    for(int k=0;k<Cout;k++){
        for(int i=1;i<H-1;i++){
            for(int j=1;j<W-1;j++){
#pragma HLS PIPELINE II=1
                data_t sum = bias[k];
                for(int c=0;c<Cin;c++){
                    for(int ki=0;ki<3;ki++){
                        for(int kj=0;kj<3;kj++){
                            sum += input[c][i+ki-1][j+kj-1] *
                                   weights[k][c][ki][kj];
                        }
                    }
                }
                output[k][i][j] = sum;
            }
        }
    }
}
