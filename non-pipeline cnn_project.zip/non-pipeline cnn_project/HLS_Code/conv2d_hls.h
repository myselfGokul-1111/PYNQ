#ifndef CONV2D_HLS_H
#define CONV2D_HLS_H

#include <ap_fixed.h>
#include <hls_stream.h>

#define MAX_H 416
#define MAX_W 416
#define MAX_C 32
#define MAX_K 32

typedef ap_fixed<16,8> data_t;

void conv2d_hls(
    data_t input[MAX_C][MAX_H][MAX_W],
    data_t weights[MAX_K][MAX_C][3][3],
    data_t bias[MAX_K],
    data_t output[MAX_K][MAX_H][MAX_W],
    int H, int W, int Cin, int Cout
);

#endif
