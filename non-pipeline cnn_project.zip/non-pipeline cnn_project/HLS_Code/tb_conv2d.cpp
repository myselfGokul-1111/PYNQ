#include "conv2d_hls.h"
#include <iostream>

int main() {
    static data_t input[MAX_C][MAX_H][MAX_W];
    static data_t weights[MAX_K][MAX_C][3][3];
    static data_t bias[MAX_K];
    static data_t output[MAX_K][MAX_H][MAX_W];

    // Initialize
    for(int c=0;c<3;c++)
        for(int i=0;i<32;i++)
            for(int j=0;j<32;j++)
                input[c][i][j] = 1;

    for(int k=0;k<8;k++){
        bias[k] = 0;
        for(int c=0;c<3;c++)
            for(int i=0;i<3;i++)
                for(int j=0;j<3;j++)
                    weights[k][c][i][j] = 1;
    }

    conv2d_hls(input,weights,bias,output,32,32,3,8);

    std::cout << "Output[0][16][16] = "
              << output[0][16][16] << std::endl;

    return 0;
}
